<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-semibold mb-4">Admin kezdőlap</h1>
<p class="text-gray-600">Válassz a bal oldali menüből:</p>
<ul class="list-disc ml-6 mt-2">
    <li>Galéria kezelése – képek feltöltése, szerkesztése, törlése</li>
    <li>Fellépések kezelése – (hamarosan) események CRUD</li>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oktav\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>