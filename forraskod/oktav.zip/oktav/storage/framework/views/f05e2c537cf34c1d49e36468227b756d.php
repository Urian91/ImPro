<?php $__env->startSection('title', $event->title . ' – lezárult'); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">

        <div class="card space-y-4">
            
            <div>
                <?php if(!empty($event->image_url)): ?>
                    <img src="<?php echo e($event->image_url); ?>" alt="<?php echo e($event->title); ?>"
                         class="w-full h-40 object-cover rounded-md border">
                <?php else: ?>
                    <img src="https://via.placeholder.com/400x200?text=ImPro"
                         alt="ImPro"
                         class="w-full h-40 object-cover rounded-md border">
                <?php endif; ?>
            </div>

            <div class="space-y-2">
                <h1 class="text-2xl font-semibold"><?php echo e($event->title); ?></h1>

                <?php if($event->when): ?>
                    <div class="text-sm text-gray-600">
                        <strong>Időpont:</strong> <?php echo e($event->when->format('Y.m.d. H:i')); ?>

                    </div>
                <?php endif; ?>

                <?php if(!empty($event->location)): ?>
                    <div class="text-sm text-gray-600">
                        <strong>Helyszín:</strong> <?php echo e($event->location); ?>

                    </div>
                <?php endif; ?>

                <?php if(!empty($event->city)): ?>
                    <div class="text-sm text-gray-600">
                        <strong>Város:</strong> <?php echo e($event->city); ?>

                    </div>
                <?php endif; ?>

                <div class="p-3 rounded bg-yellow-50 border border-yellow-200 text-yellow-900">
                    Ez az esemény már <strong>lezárult</strong>. Köszönjük az érdeklődést!
                </div>

                <div class="mt-4 flex flex-wrap gap-3">
                    <a href="<?php echo e(route('events.index')); ?>" class="btn" style="background:#2563eb">
                        Vissza a fellépésekhez
                    </a>
                    <a href="<?php echo e(route('home')); ?>" class="btn">Főoldal</a>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oktav\resources\views/events/past.blade.php ENDPATH**/ ?>