<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasColumn('events', 'venue')) {
            Schema::table('events', function (Blueprint $table) {
                $table->string('venue', 255)->nullable()->change();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('events', 'venue')) {
            Schema::table('events', function (Blueprint $table) {
                $table->string('venue', 255)->nullable(false)->change();
            });
        }
    }
};
