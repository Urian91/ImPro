<?php $__env->startComponent('mail::message'); ?>
# Foglalás megerősítése

Kedves <?php echo new \Illuminate\Support\EncodedHtmlString($booking->fullName()); ?>!

Köszönjük a foglalást az alábbi eseményre:

**Esemény:** <?php echo new \Illuminate\Support\EncodedHtmlString($event->title); ?>

**Helyszín:** <?php echo new \Illuminate\Support\EncodedHtmlString($event->venue); ?>, <?php echo new \Illuminate\Support\EncodedHtmlString($event->city); ?>

**Időpont:** <?php echo new \Illuminate\Support\EncodedHtmlString($event->starts_at->format('Y.m.d. H:i')); ?>

**Jegyek száma:** <?php echo new \Illuminate\Support\EncodedHtmlString($booking->quantity); ?>


**Az Ön számlázási címe:** <?php echo new \Illuminate\Support\EncodedHtmlString($booking->fullAddress()); ?>


<?php $__env->startComponent('mail::panel'); ?>
A foglalásod státusza: **<?php echo new \Illuminate\Support\EncodedHtmlString(strtoupper($booking->status)); ?>**
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => route('events.show', $event)]); ?>
Esemény oldala
<?php echo $__env->renderComponent(); ?>

Üdvözlettel,
**ImPro csapat**
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\oktav\resources\views/emails/booking/confirmed.blade.php ENDPATH**/ ?>