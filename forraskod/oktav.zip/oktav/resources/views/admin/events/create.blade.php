@extends('layouts.app')
@section('title', 'Új esemény hozzáadása')

@section('content')
<div class="space-y-6">
    <div class="flex items-center justify-between">
        <a href="{{ route('admin.events.index') }}" class="underline">← Vissza a listához</a>
    </div>

    <form action="{{ route('admin.events.store') }}" method="POST" enctype="multipart/form-data" class="card space-y-4">
        @csrf

        <div>
            <label class="block text-sm font-medium">Cím</label>
            <input name="title" value="{{ old('title') }}" class="mt-1 w-full rounded border-gray-300" required>
            @error('title') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
        </div>

        <div>
            <label class="block text-sm font-medium">Leírás</label>
            <textarea name="description" rows="6" class="mt-1 w-full rounded border-gray-300">{{ old('description') }}</textarea>
            @error('description') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium">Helyszín</label>
                <input name="location" value="{{ old('location') }}" class="mt-1 w-full rounded border-gray-300">
                @error('location') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="block text-sm font-medium">Város</label>
                <input name="city" value="{{ old('city') }}" class="mt-1 w-full rounded border-gray-300">
                @error('city') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium">Időpont</label>
            <input type="datetime-local" name="starts_at"
                   value="{{ old('starts_at') }}"
                   class="mt-1 w-full rounded border-gray-300">
            @error('starts_at') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium">Férőhely</label>
                <input type="number" name="capacity" value="{{ old('capacity') }}" class="mt-1 w-full rounded border-gray-300">
                @error('capacity') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
            </div>
            <label class="inline-flex items-center gap-2 mt-6">
                <input type="checkbox" name="is_published" value="1" {{ old('is_published') ? 'checked' : '' }}>
                <span>Publikus</span>
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium">Kép feltöltése</label>
            <input type="file" name="image" class="mt-1">
            @error('image') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
        </div>

        <div>
            <button class="btn">Létrehozás</button>
        </div>
    </form>
</div>
@endsection
