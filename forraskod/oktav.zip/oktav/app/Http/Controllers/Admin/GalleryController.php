<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GalleryImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class GalleryController extends Controller
{
    public function index()
    {
        $images = GalleryImage::orderBy('sort_order')
            ->orderByDesc('created_at')
            ->paginate(24);

        return view('admin.gallery.index', compact('images'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'images'       => ['required','array','min:1'],
            'images.*'     => ['file','image','max:5120'],
            'alt_text'     => ['nullable','array'],
            'alt_text.*'   => ['nullable','string','max:150'],
            'sort_order'   => ['nullable','array'],
            'sort_order.*' => ['nullable','integer','min:0','max:1000000'],
        ]);

        foreach ($request->file('images') as $i => $file) {
            $stored = $file->store('gallery', 'public');

            \App\Models\GalleryImage::create([
                'path'       => $stored,
                'alt_text'   => data_get($validated, "alt_text.$i"),
                'sort_order' => (int) data_get($validated, "sort_order.$i", 0),
            ]);
        }

        return redirect()->route('admin.gallery.index')->with('success', 'Képek feltöltve.');
    }

    public function edit(\App\Models\GalleryImage $gallery)
    {
        return view('admin.gallery.edit', ['img' => $gallery]);
    }

    public function update(Request $request, \App\Models\GalleryImage $gallery)
    {
        $data = $request->validate([
            'alt_text'   => ['nullable','string','max:150'],
            'sort_order' => ['required','integer','min:0','max:1000000'],
            'replace'    => ['nullable','file','image','max:5120'],
        ]);

        if ($request->hasFile('replace')) {
            if ($gallery->path && Storage::disk('public')->exists($gallery->path)) {
                Storage::disk('public')->delete($gallery->path);
            }
            $gallery->path = $request->file('replace')->store('gallery', 'public');
        }

        $gallery->alt_text   = $data['alt_text'] ?? null;
        $gallery->sort_order = $data['sort_order'];
        $gallery->save();

        return redirect()->route('admin.gallery.index')->with('success', 'Kép frissítve.');
    }

    public function destroy(\App\Models\GalleryImage $gallery)
    {
        if ($gallery->path && Storage::disk('public')->exists($gallery->path)) {
            Storage::disk('public')->delete($gallery->path);
        }

        $gallery->delete();

        return redirect()->route('admin.gallery.index')->with('success', 'Kép törölve.');
    }
}
