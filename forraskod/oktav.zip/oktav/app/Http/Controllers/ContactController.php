<?php

namespace App\Http\Controllers;

class ContactController extends Controller
{
    public function index()
    {
        $title = 'Kapcsolat – ImPro társulat';


        $contact = [
            'phone' => '+36 30 / 690 8807',
            'email' => 'impro.tarsulat.hmvhely@gmail.com',
            'person' => 'Molnár Ákos',
            'address' => 'Hódmezővásárhely, Dr. Rapcsák András út 7, 6800',
            'maps_embed' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2690.129697081305!2d20.3209487!3d46.4185054!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x474482d24a20e7df%3A0x7b6ddc5aaba3a099!2sH%C3%B3dmez%C5%91v%C3%A1s%C3%A1rhely%2C%20Dr.%20Rapcs%C3%A1k%20Andr%C3%A1s%20%C3%BAt%207%2C%206800!5e0!3m2!1shu!2shu!4v1700000000000!5m2!1shu!2shu',
        ];

        return view('contact.index', compact('title', 'contact'));
    }
}
