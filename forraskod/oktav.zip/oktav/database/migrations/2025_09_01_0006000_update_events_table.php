<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('events', function (Blueprint $table) {
            // csak a starts_at mezőt tartjuk meg
            if (!Schema::hasColumn('events', 'starts_at')) {
                $table->dateTime('starts_at')->nullable()->after('city');
            }

            // ha vannak régi oszlopok, eltávolíthatod
            foreach (['date','start_at','datetime'] as $col) {
                if (Schema::hasColumn('events', $col)) {
                    $table->dropColumn($col);
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('events', function (Blueprint $table) {
            // rollback: csak egy egyszerű date oszlop vissza
            if (!Schema::hasColumn('events', 'date')) {
                $table->date('date')->nullable();
            }
        });
    }
};
