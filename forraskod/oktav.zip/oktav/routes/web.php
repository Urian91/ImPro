<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

// Publikus controllerek
use App\Http\Controllers\PageController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\ContactController;

// Auth (Breeze)
use App\Http\Controllers\ProfileController;

// Admin kontrollerek
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\GalleryController as AdminGalleryController;
use App\Http\Controllers\Admin\EventController as AdminEventController;

// Middleware osztályok
use App\Http\Middleware\AdminOnly;
use App\Http\Middleware\GalleryAccess;

/*
|--------------------------------------------------------------------------
| Publikus oldalak
|--------------------------------------------------------------------------
*/

// KEZDŐLAP -> RÓLUNK
Route::get('/', [PageController::class, 'about'])->name('home');
Route::get('/rolunk', [PageController::class, 'about'])->name('about');

// Fellépések publikus
Route::get('/fellepeseink', [EventController::class, 'index'])->name('events.index');
Route::get('/fellepeseink/{event}', [EventController::class, 'show'])
    ->whereNumber('event')
    ->name('events.show');

// Foglalás (publikus űrlap + mentés)
Route::get('/fellepeseink/{event}/foglalas', [BookingController::class, 'create'])
    ->whereNumber('event')
    ->name('bookings.create');
Route::post('/fellepeseink/{event}/foglalas', [BookingController::class, 'store'])
    ->whereNumber('event')
    ->name('bookings.store');

// Galéria publikus
Route::get('/galeria', [GalleryController::class, 'index'])->name('gallery.index');

// Kapcsolat publikus
Route::get('/kapcsolat', [ContactController::class, 'index'])->name('contact.index');

/*
|--------------------------------------------------------------------------
| Breeze (dashboard + profil)
|--------------------------------------------------------------------------
*/
Route::get('/dashboard', fn () => view('dashboard'))
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

/*
|--------------------------------------------------------------------------
| Admin terület – szerepfüggő belépő és jogosultságok
| - /admin: okos átirányítás (admin -> dashboard, gallery -> galéria admin)
| - /admin/dashboard + /admin/events/* : csak admin (AdminOnly)
| - /admin/gallery/* : admin + gallery (GalleryAccess middleware)
|--------------------------------------------------------------------------
*/
Route::prefix('admin')
    ->as('admin.')
    ->middleware(['auth'])
    ->group(function () {

        // /admin -> szerep alapú átirányítás (role mező szerint)
        Route::get('/', function () {
            $u = Auth::user();
            if ($u->role === 'admin')   return redirect()->route('admin.dashboard');
            if ($u->role === 'gallery') return redirect()->route('admin.gallery.index');
            abort(403);
        })->name('home');

        // Dashboard – CSAK ADMIN
        Route::get('/dashboard', [AdminDashboardController::class, 'index'])
            ->name('dashboard')
            ->middleware(AdminOnly::class);

        // Események – CSAK ADMIN
        Route::middleware(AdminOnly::class)->group(function () {
            Route::get('events',               [AdminEventController::class, 'index'])->name('events.index');
            Route::get('events/create',        [AdminEventController::class, 'create'])->name('events.create');
            Route::post('events',              [AdminEventController::class, 'store'])->name('events.store');
            Route::get('events/{event}/edit',  [AdminEventController::class, 'edit'])
                ->whereNumber('event')->name('events.edit');
            Route::put('events/{event}',       [AdminEventController::class, 'update'])
                ->whereNumber('event')->name('events.update');
            Route::delete('events/{event}',    [AdminEventController::class, 'destroy'])
                ->whereNumber('event')->name('events.destroy');
        });

        // Galéria – ADMIN + GALLERY (KÖZVETLEN OSZTÁLYOS middleware)
        Route::middleware(GalleryAccess::class)->group(function () {
            Route::get('gallery',                [AdminGalleryController::class, 'index'])->name('gallery.index');
            Route::post('gallery',               [AdminGalleryController::class, 'store'])->name('gallery.store');
            Route::get('gallery/{gallery}/edit', [AdminGalleryController::class, 'edit'])
                ->whereNumber('gallery')->name('gallery.edit');
            Route::put('gallery/{gallery}',      [AdminGalleryController::class, 'update'])
                ->whereNumber('gallery')->name('gallery.update');
            Route::delete('gallery/{gallery}',   [AdminGalleryController::class, 'destroy'])
                ->whereNumber('gallery')->name('gallery.destroy');
        });
    });

require __DIR__ . '/auth.php';
