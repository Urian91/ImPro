<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-semibold mb-4">Galéria – képek kezelése</h1>

<?php if(session('success')): ?>
    <div class="p-3 mb-4 bg-green-100 border border-green-300 rounded"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="mb-8 border rounded p-4">
    <h2 class="font-semibold mb-3">Új képek feltöltése</h2>
    <form action="<?php echo e(route('admin.gallery.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-3">
        <?php echo csrf_field(); ?>
        <div>
            <label class="block mb-1 font-medium">Képek (több is választható)</label>
            <input type="file" name="images[]" multiple accept="image/*" class="border rounded p-2 w-full">
            <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <details class="mt-2">
            <summary class="cursor-pointer text-sm text-gray-600">Opcionális: ALT + sorrend az első 5 képhez</summary>
            <div class="grid md:grid-cols-2 gap-3 mt-3">
                <?php for($i=0; $i<5; $i++): ?>
                    <div class="border rounded p-3">
                        <div class="font-medium mb-2">#<?php echo e($i+1); ?> meta</div>
                        <label class="block text-sm">ALT
                            <input type="text" name="alt_text[<?php echo e($i); ?>]" class="border rounded p-2 w-full">
                        </label>
                        <label class="block text-sm mt-2">Sorrend
                            <input type="number" name="sort_order[<?php echo e($i); ?>]" value="0" min="0" class="border rounded p-2 w-full">
                        </label>
                    </div>
                <?php endfor; ?>
            </div>
        </details>

        <div class="pt-2"><button class="px-4 py-2 bg-black text-white rounded">Feltöltés</button></div>
    </form>
</div>

<style>
.masonry{columns:1;column-gap:1rem}
@media (min-width:640px){.masonry{columns:2}}
@media (min-width:1024px){.masonry{columns:3}}
.m-item{break-inside:avoid;margin-bottom:1rem;border-radius:.75rem;overflow:hidden;border:1px solid #e5e7eb;background:#fff;position:relative}
.m-item img{width:100%;height:auto;display:block}
.actions{position:absolute;top:.5rem;right:.5rem;display:flex;gap:.25rem}
.btn{border:none;border-radius:.5rem;padding:.35rem .55rem;color:#fff;cursor:pointer}
.btn-edit{background:#2563eb}
.btn-del{background:#dc2626}
</style>

<?php if($images->isEmpty()): ?>
    <p class="text-gray-600">Még nincs kép feltöltve.</p>
<?php else: ?>
    <div class="masonry">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <figure class="m-item">
                <img src="<?php echo e(asset('storage/'.$img->path)); ?>" alt="<?php echo e($img->alt_text ?? ''); ?>">
                <div class="actions">
                    <a class="btn btn-edit" href="<?php echo e(route('admin.gallery.edit', $img)); ?>">Szerk.</a>
                    <form method="POST" action="<?php echo e(route('admin.gallery.destroy', $img)); ?>" onsubmit="return confirm('Törlöd a képet?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-del">Törlés</button>
                    </form>
                </div>
            </figure>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="mt-6"><?php echo e($images->links()); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oktav\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>