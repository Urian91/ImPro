@extends('admin.layout')

@section('content')
<h1 class="text-2xl font-semibold mb-4">Galéria – képek kezelése</h1>

@if (session('success'))
    <div class="p-3 mb-4 bg-green-100 border border-green-300 rounded">{{ session('success') }}</div>
@endif

<div class="mb-8 border rounded p-4">
    <h2 class="font-semibold mb-3">Új képek feltöltése</h2>
    <form action="{{ route('admin.gallery.store') }}" method="POST" enctype="multipart/form-data" class="space-y-3">
        @csrf
        <div>
            <label class="block mb-1 font-medium">Képek (több is választható)</label>
            <input type="file" name="images[]" multiple accept="image/*" class="border rounded p-2 w-full">
            @error('images') <div class="text-red-600 text-sm">{{ $message }}</div> @enderror
        </div>

        <details class="mt-2">
            <summary class="cursor-pointer text-sm text-gray-600">Opcionális: ALT + sorrend az első 5 képhez</summary>
            <div class="grid md:grid-cols-2 gap-3 mt-3">
                @for ($i=0; $i<5; $i++)
                    <div class="border rounded p-3">
                        <div class="font-medium mb-2">#{{ $i+1 }} meta</div>
                        <label class="block text-sm">ALT
                            <input type="text" name="alt_text[{{ $i }}]" class="border rounded p-2 w-full">
                        </label>
                        <label class="block text-sm mt-2">Sorrend
                            <input type="number" name="sort_order[{{ $i }}]" value="0" min="0" class="border rounded p-2 w-full">
                        </label>
                    </div>
                @endfor
            </div>
        </details>

        <div class="pt-2"><button class="px-4 py-2 bg-black text-white rounded">Feltöltés</button></div>
    </form>
</div>

<style>
.masonry{columns:1;column-gap:1rem}
@media (min-width:640px){.masonry{columns:2}}
@media (min-width:1024px){.masonry{columns:3}}
.m-item{break-inside:avoid;margin-bottom:1rem;border-radius:.75rem;overflow:hidden;border:1px solid #e5e7eb;background:#fff;position:relative}
.m-item img{width:100%;height:auto;display:block}
.actions{position:absolute;top:.5rem;right:.5rem;display:flex;gap:.25rem}
.btn{border:none;border-radius:.5rem;padding:.35rem .55rem;color:#fff;cursor:pointer}
.btn-edit{background:#2563eb}
.btn-del{background:#dc2626}
</style>

@if($images->isEmpty())
    <p class="text-gray-600">Még nincs kép feltöltve.</p>
@else
    <div class="masonry">
        @foreach($images as $img)
            <figure class="m-item">
                <img src="{{ asset('storage/'.$img->path) }}" alt="{{ $img->alt_text ?? '' }}">
                <div class="actions">
                    <a class="btn btn-edit" href="{{ route('admin.gallery.edit', $img) }}">Szerk.</a>
                    <form method="POST" action="{{ route('admin.gallery.destroy', $img) }}" onsubmit="return confirm('Törlöd a képet?')">
                        @csrf @method('DELETE')
                        <button class="btn btn-del">Törlés</button>
                    </form>
                </div>
            </figure>
        @endforeach
    </div>
    <div class="mt-6">{{ $images->links() }}</div>
@endif
@endsection
