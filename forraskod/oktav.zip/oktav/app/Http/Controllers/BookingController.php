<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use App\Mail\BookingConfirmedMail;

class BookingController extends Controller
{
    // A külön /foglalas oldal helyett irányítsunk az esemény oldalára az űrlaphoz
    public function create(Event $event)
    {
        abort_if(!$event->is_published ?? false, 404);
        abort_if(method_exists($event, 'isPast') && $event->isPast(), 403);

        return redirect()->to(route('events.show', $event) . '#foglalas');
    }

    public function store(Request $request, Event $event)
    {
        abort_if(!$event->is_published ?? false, 404);
        abort_if(method_exists($event, 'isPast') && $event->isPast(), 403, 'Lejárt eseményre nem lehet foglalni.');

        $validated = $request->validate([
            'last_name'      => ['required','string','min:2','max:100'],
            'first_name'     => ['required','string','min:2','max:100'],
            'zip_code'       => ['required','string','min:3','max:10'],
            'city'           => ['required','string','min:2','max:120'],
            'street_address' => ['required','string','min:5','max:190'],
            'email'          => ['required','email','max:190'],
            'quantity'       => ['required','integer','min:1','max:20'],
            'note'           => ['nullable','string','max:1000'],
        ]);

        $booking = DB::transaction(function () use ($event, $validated) {
            $locked = Event::where('id', $event->id)->lockForUpdate()->first();

            if (!is_null($locked->capacity)) {
                $already   = (int) $locked->bookings()->sum('quantity');
                $requested = (int) $validated['quantity'];
                if ($already + $requested > (int) $locked->capacity) {
                    abort(422, 'Sajnos kevés a szabad hely ehhez a darabszámhoz.');
                }
            }

            return Booking::create([
                'event_id'       => $locked->id,
                'last_name'      => $validated['last_name'],
                'first_name'     => $validated['first_name'],
                'zip_code'       => $validated['zip_code'],
                'city'           => $validated['city'],
                'street_address' => $validated['street_address'],
                'email'          => $validated['email'],
                'quantity'       => (int) $validated['quantity'],
                'note'           => $validated['note'] ?? null,
                'status'         => 'confirmed',
            ]);
        });

        try {
            Mail::to($booking->email)->send(new BookingConfirmedMail($booking));
        } catch (\Throwable $e) {
            Log::warning('Booking mail failed', ['booking_id' => $booking->id, 'error' => $e->getMessage()]);
        }

        // Siker: vissza az esemény oldalára az űrlaphoz és üzenet
        return redirect()
            ->to(route('events.show', $event) . '#foglalas')
            ->with('success', 'Foglalás sikeres! Visszaigazoló e-mailt küldtünk.');
    }
}
