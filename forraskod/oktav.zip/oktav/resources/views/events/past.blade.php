@extends('layouts.app')
@section('title', $event->title . ' – lezárult')

@section('content')
    <div class="space-y-6">

        <div class="card space-y-4">
            {{-- Kép – a bevált formátumban --}}
            <div>
                @if(!empty($event->image_url))
                    <img src="{{ $event->image_url }}" alt="{{ $event->title }}"
                         class="w-full h-40 object-cover rounded-md border">
                @else
                    <img src="https://via.placeholder.com/400x200?text=ImPro"
                         alt="ImPro"
                         class="w-full h-40 object-cover rounded-md border">
                @endif
            </div>

            <div class="space-y-2">
                <h1 class="text-2xl font-semibold">{{ $event->title }}</h1>

                @if($event->when)
                    <div class="text-sm text-gray-600">
                        <strong>Időpont:</strong> {{ $event->when->format('Y.m.d. H:i') }}
                    </div>
                @endif

                @if(!empty($event->location))
                    <div class="text-sm text-gray-600">
                        <strong>Helyszín:</strong> {{ $event->location }}
                    </div>
                @endif

                @if(!empty($event->city))
                    <div class="text-sm text-gray-600">
                        <strong>Város:</strong> {{ $event->city }}
                    </div>
                @endif

                <div class="p-3 rounded bg-yellow-50 border border-yellow-200 text-yellow-900">
                    Ez az esemény már <strong>lezárult</strong>. Köszönjük az érdeklődést!
                </div>

                <div class="mt-4 flex flex-wrap gap-3">
                    <a href="{{ route('events.index') }}" class="btn" style="background:#2563eb">
                        Vissza a fellépésekhez
                    </a>
                    <a href="{{ route('home') }}" class="btn">Főoldal</a>
                </div>
            </div>
        </div>

    </div>
@endsection
