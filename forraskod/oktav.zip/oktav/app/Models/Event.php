<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Event extends Model
{
    // Engedélyezett mezők
    protected $fillable = [
        'title',
        'description',
        'location',
        'venue',
        'city',
        'starts_at',
        'capacity',
        'is_published',
        'image_path',
    ];

    protected $casts = [
        'starts_at'    => 'datetime',
        'is_published' => 'boolean',
    ];

    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }

    public function remainingCapacity(): ?int
    {
        if (is_null($this->capacity)) return null;
        $booked = (int) $this->bookings()->sum('quantity');
        return max(0, (int) $this->capacity - $booked);
    }


    public function getWhenAttribute(): ?Carbon
    {
        return $this->starts_at instanceof Carbon
            ? $this->starts_at
            : ($this->starts_at ? Carbon::parse($this->starts_at) : null);
    }

    public function formattedWhen(string $format = 'Y.m.d. H:i'): ?string
    {
        return $this->when ? $this->when->format($format) : null;
    }

    /** Elmúlt-e már az esemény? */
    public function isPast(): bool
    {
        return $this->when ? $this->when->isPast() : false;
    }

    /** Kép URL accessor */
    public function getImageUrlAttribute(): ?string
    {
        $val = $this->image_path ?? null;
        if (!$val) return null;

        if (preg_match('~^https?://~i', $val)) return $val;

        if (file_exists(public_path('storage/' . ltrim($val, '/')))) {
            return asset('storage/' . ltrim($val, '/'));
        }
        if (file_exists(public_path(ltrim($val, '/')))) {
            return asset(ltrim($val, '/'));
        }
        return asset('storage/' . ltrim($val, '/'));
    }

    public function imageUrl(): ?string
    {
        return $this->image_url;
    }
}
