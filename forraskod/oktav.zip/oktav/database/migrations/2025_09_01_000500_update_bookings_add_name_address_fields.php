<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('bookings')) {
            Schema::table('bookings', function (Blueprint $table) {
                // Név bontása
                if (!Schema::hasColumn('bookings', 'last_name')) {
                    $table->string('last_name', 100)->nullable()->after('event_id');
                }
                if (!Schema::hasColumn('bookings', 'first_name')) {
                    $table->string('first_name', 100)->nullable()->after('last_name');
                }

                // Cím bontása
                if (!Schema::hasColumn('bookings', 'zip_code')) {
                    $table->string('zip_code', 10)->nullable()->after('first_name');
                }
                if (!Schema::hasColumn('bookings', 'city')) {
                    $table->string('city', 120)->nullable()->after('zip_code');
                }
                if (!Schema::hasColumn('bookings', 'street_address')) {
                    $table->string('street_address', 190)->nullable()->after('city');
                }

                // biztosítsuk, hogy legyen email és quantity is
                if (!Schema::hasColumn('bookings', 'email')) {
                    $table->string('email', 190)->nullable()->after('street_address');
                }
                if (!Schema::hasColumn('bookings', 'quantity')) {
                    $table->unsignedInteger('quantity')->default(1)->after('email');
                }

                if (!Schema::hasColumn('bookings', 'note')) {
                    $table->text('note')->nullable()->after('quantity');
                }
                if (!Schema::hasColumn('bookings', 'status')) {
                    $table->string('status', 30)->default('confirmed')->after('note');
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('bookings')) {
            Schema::table('bookings', function (Blueprint $table) {
                foreach (['status','note','quantity','email','street_address','city','zip_code','first_name','last_name'] as $col) {
                    if (Schema::hasColumn('bookings', $col)) {
                        $table->dropColumn($col);
                    }
                }
            });
        }
    }
};
