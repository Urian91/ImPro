@extends('layouts.app')

@section('content')
<h1 class="text-3xl font-bold mb-6">Fellépéseink</h1>

@if($events->isEmpty())
    <p class="text-gray-600">Jelenleg nincs meghirdetett esemény.</p>
@else
    <div class="space-y-6">
        @foreach($events as $event)
            <article class="border rounded-xl overflow-hidden">
                <div class="grid md:grid-cols-3 gap-0">
                    <div class="md:col-span-1">
                        <div style="aspect-ratio:16/9;background:#f3f4f6;overflow:hidden;">
                            @if($event->imageUrl())
                                <img src="{{ $event->imageUrl() }}" alt="{{ $event->title }}" style="width:100%;height:100%;object-fit:cover;">
                            @endif
                        </div>
                    </div>
                    <div class="p-4 md:col-span-2">
                        <h2 class="text-xl font-semibold">
                            <a href="{{ route('events.show', $event) }}">{{ $event->title }}</a>
                        </h2>
                        <div class="text-gray-600 text-sm mb-2">
                            {{ $event->starts_at->format('Y.m.d. H:i') }} • {{ $event->venue }}, {{ $event->city }}
                        </div>
                        @if($event->capacity)
                            <div class="text-gray-600 text-sm mb-2">
                                Férőhely: {{ $event->capacity }} • Hátralévő: {{ $event->remainingCapacity() }}
                            </div>
                        @endif
                        <p class="mb-3 line-clamp-3">{{ Str::limit($event->description, 240) }}</p>
                        <a href="{{ route('events.show', $event) }}" class="btn">Részletek & Foglalás</a>
                    </div>
                </div>
            </article>
        @endforeach
    </div>
@endif
@endsection
