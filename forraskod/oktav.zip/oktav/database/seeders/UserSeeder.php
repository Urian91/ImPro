<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Dani – admin
        User::updateOrCreate(
            ['email' => 'dani@impro.hu'],
            [
                'name' => 'Dani',
                'password' => Hash::make('12345'),
                'role' => User::ROLE_ADMIN,
                'email_verified_at' => now(),
            ]
        );

        // Kati – csak galéria
        User::updateOrCreate(
            ['email' => 'kati@impro.hu'],
            [
                'name' => 'Kati',
                'password' => Hash::make('12345'),
                'role' => User::ROLE_GALLERY,
                'email_verified_at' => now(),
            ]
        );
    }
}
