<?php

namespace App\Policies;

use App\Models\User;

class GalleryPolicy
{
    /**
     * Admin + gallery szerepnek minden action engedélyezett
     * a galéria admin felületen.
     */
    public function before(User $user, string $ability)
    {
        if (in_array($user->role, [User::ROLE_ADMIN, User::ROLE_GALLERY], true)) {
            return true;
        }
        return null;
    }
}
