<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin – ImPro</title>
    @vite(['resources/css/app.css','resources/js/app.js'])
    <style>
        .admin-wrap{display:grid;grid-template-columns:220px 1fr;min-height:100vh}
        .sidebar{border-right:1px solid #e5e7eb;padding:1rem}
        .sidebar a{display:block;padding:.5rem .75rem;border-radius:.5rem;margin:.15rem 0;text-decoration:none}
        .sidebar a:hover{background:#f3f4f6}
        .content{padding:1.25rem}
    </style>
</head>
<body class="bg-white text-gray-900">
<div class="admin-wrap">
    <aside class="sidebar">
        <div class="font-bold mb-3">ImPro – Admin</div>
        <nav>
            <a href="{{ route('admin.dashboard') }}">Kezdőlap</a>
            <a href="{{ route('admin.gallery.index') }}">Galéria kezelése</a>
            <a href="{{ route('admin.events.index') }}">Fellépések kezelése</a>
            <a href="{{ route('home') }}">← Vissza a honlapra</a>
        </nav>
        <form method="POST" action="{{ route('logout') }}" class="mt-4">
            @csrf
            <button class="px-3 py-2 border rounded">Kijelentkezés</button>
        </form>
    </aside>
    <main class="content">
        @yield('content')
    </main>
</div>
</body>
</html>
