<form action="<?php echo e(route('bookings.store', $event)); ?>" method="POST" class="space-y-4">
    <?php echo csrf_field(); ?>

    <?php if(session('success')): ?>
        <div class="card bg-green-50 border-green-200 text-green-800">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="card bg-red-50 border-red-200 text-red-700">
            <ul class="list-disc pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card space-y-4">
        <div>
            <label class="block text-sm font-medium">Vezetéknév</label>
            <input name="last_name" value="<?php echo e(old('last_name')); ?>" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">Keresztnév</label>
            <input name="first_name" value="<?php echo e(old('first_name')); ?>" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">Irányítószám</label>
            <input name="zip_code" value="<?php echo e(old('zip_code')); ?>" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">Település</label>
            <input name="city" value="<?php echo e(old('city')); ?>" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">Utca, házszám</label>
            <input name="street_address" value="<?php echo e(old('street_address')); ?>" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">E-mail cím</label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required class="mt-1 w-full rounded border-gray-300" />
            <p class="text-xs text-gray-500 mt-1">Erre a címre küldjük a visszaigazolást.</p>
        </div>
        <div>
            <label class="block text-sm font-medium">Hány jegyet foglal</label>
            <input type="number" min="1" name="quantity" value="<?php echo e(old('quantity', 1)); ?>" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">Megjegyzés (opcionális)</label>
            <textarea name="note" rows="3" class="mt-1 w-full rounded border-gray-300"><?php echo e(old('note')); ?></textarea>
        </div>

        <div class="flex items-center gap-4">
            <button type="submit" class="btn">Foglalás elküldése</button>
            <a href="<?php echo e(route('events.index')); ?>" class="underline">Vissza a listához</a>
        </div>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\oktav\resources\views/bookings/_form.blade.php ENDPATH**/ ?>