<?php $__env->startSection('title', 'Esemény szerkesztése: ' . $event->title); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    <a href="<?php echo e(route('admin.events.index')); ?>" class="underline">← Vissza a listához</a>

    <?php if(session('success')): ?>
        <div class="card bg-green-50 border-green-200 text-green-800"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.events.update', $event)); ?>" method="POST" enctype="multipart/form-data" class="card space-y-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label class="block text-sm font-medium">Cím</label>
            <input name="title" value="<?php echo e(old('title', $event->title)); ?>" class="mt-1 w-full rounded border-gray-300" required>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-sm font-medium">Leírás</label>
            <textarea name="description" rows="6" class="mt-1 w-full rounded border-gray-300"><?php echo e(old('description', $event->description)); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium">Helyszín</label>
                <input name="location" value="<?php echo e(old('location', $event->location)); ?>" class="mt-1 w-full rounded border-gray-300">
                <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-medium">Város</label>
                <input name="city" value="<?php echo e(old('city', $event->city)); ?>" class="mt-1 w-full rounded border-gray-300">
                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div>
            <label for="starts_at" class="block text-sm font-medium">Időpont</label>
            <input
                type="datetime-local"
                id="starts_at"
                name="starts_at"
                value="<?php echo e(old('starts_at', $event->starts_at ? $event->starts_at->format('Y-m-d\TH:i') : '')); ?>"
                class="mt-1 w-full rounded border-gray-300"
            >
            <?php $__errorArgs = ['starts_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium">Férőhely</label>
                <input type="number" name="capacity" value="<?php echo e(old('capacity', $event->capacity)); ?>" class="mt-1 w-full rounded border-gray-300">
                <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <label class="inline-flex items-center gap-2 mt-6">
                <input type="checkbox" name="is_published" value="1" <?php echo e(old('is_published', $event->is_published) ? 'checked' : ''); ?>>
                <span>Publikus</span>
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium">Kép feltöltése</label>
            <input type="file" name="image" class="mt-1">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-sm text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php if($event->image_url): ?>
                <div class="mt-3">
                    <img src="<?php echo e($event->image_url); ?>" alt="borító"
                         class="w-full h-40 object-cover rounded-md border">
                </div>
            <?php endif; ?>
        </div>

        <div class="flex gap-3">
            <button class="btn">Mentés</button>
            <a href="<?php echo e(route('events.show', $event)); ?>" class="underline" target="_blank">Megnézem az oldalon</a>
        </div>
    </form>

    
    <form action="<?php echo e(route('admin.events.destroy', $event)); ?>" method="POST" class="mt-6"
          onsubmit="return confirm('Biztosan törlöd az eseményt? Ez a művelet nem visszavonható!')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn bg-red-600 hover:bg-red-700">
            Esemény törlése
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oktav\resources\views/admin/events/edit.blade.php ENDPATH**/ ?>