<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\TrimStrings as Middleware;

class TrimStrings extends Middleware
{
    /**
     * Ezeket a mezőket NEM vágjuk le (jelszavak).
     */
    protected $except = [
        'current_password',
        'password',
        'password_confirmation',
    ];
}
