<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        $email = 'dani@impro.hu';      // ← IDE A SAJÁT E-MAILEDET
        $name  = 'Admin';
        $pass  = '12345';           // ← IDE A SAJÁT JELSZAVAD

        $user = User::firstOrCreate(
            ['email' => $email],
            [
                'name' => $name,
                'password' => Hash::make($pass),
                'is_admin' => true,
            ]
        );

        // Ha már létezett a user, biztosítsuk, hogy admin legyen
        if (!$user->is_admin) {
            $user->is_admin = true;
            $user->save();
        }
    }
}
