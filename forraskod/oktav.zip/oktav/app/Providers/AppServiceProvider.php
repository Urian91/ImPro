<?php

namespace App\Providers;

use App\Models\User;
use App\Models\GalleryImage;
use App\Policies\GalleryPolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    protected $policies = [
        GalleryImage::class => GalleryPolicy::class,
    ];

    public function boot(): void
    {
        $this->registerPolicies();

        Gate::define('admin', fn(User $u) => $u->role === User::ROLE_ADMIN);
        Gate::define('manage-events', fn(User $u) => $u->role === User::ROLE_ADMIN);
        Gate::define('manage-gallery', fn(User $u) =>
            in_array($u->role, [User::ROLE_ADMIN, User::ROLE_GALLERY], true)
        );
    }
}
