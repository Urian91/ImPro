<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Ha nincs event_id: hozzáadjuk és FK-t is állítunk
        if (!Schema::hasColumn('bookings', 'event_id')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->unsignedBigInteger('event_id')->after('id');
                $table->foreign('event_id')->references('id')->on('events')->cascadeOnDelete();
            });
        }

        // Ha nincs quantity: hozzáadjuk
        if (!Schema::hasColumn('bookings', 'quantity')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->unsignedInteger('quantity')->default(1)->after('email');
            });
        }

        // Opcionális: ha hiányoznának ezek is, pótoljuk
        if (!Schema::hasColumn('bookings', 'full_name')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->string('full_name', 120)->after('event_id');
            });
        }
        if (!Schema::hasColumn('bookings', 'address')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->string('address', 255)->nullable()->after('full_name');
            });
        }
        if (!Schema::hasColumn('bookings', 'email')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->string('email', 190)->after('address');
            });
        }
        if (!Schema::hasColumn('bookings', 'note')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->text('note')->nullable()->after('quantity');
            });
        }
        if (!Schema::hasColumn('bookings', 'status')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->string('status', 30)->default('confirmed')->after('note');
            });
        }
    }

    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            if (Schema::hasColumn('bookings', 'status'))   $table->dropColumn('status');
            if (Schema::hasColumn('bookings', 'note'))     $table->dropColumn('note');
            if (Schema::hasColumn('bookings', 'quantity')) $table->dropColumn('quantity');

            if (Schema::hasColumn('bookings', 'email'))     $table->dropColumn('email');
            if (Schema::hasColumn('bookings', 'address'))   $table->dropColumn('address');
            if (Schema::hasColumn('bookings', 'full_name')) $table->dropColumn('full_name');

            if (Schema::hasColumn('bookings', 'event_id')) {
                $table->dropForeign(['event_id']);
                $table->dropColumn('event_id');
            }
        });
    }
};
