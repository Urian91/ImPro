<?php

namespace App\Http\Controllers;

class PageController extends Controller
{

    public function about()
    {
        $title = 'Rólunk – ImPro társulat';

        return view('pages.about', compact('title'));
    }
}
