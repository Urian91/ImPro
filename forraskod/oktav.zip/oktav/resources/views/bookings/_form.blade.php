<form action="{{ route('bookings.store', $event) }}" method="POST" class="space-y-4">
    @csrf

    @if (session('success'))
        <div class="card bg-green-50 border-green-200 text-green-800">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="card bg-red-50 border-red-200 text-red-700">
            <ul class="list-disc pl-5">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card space-y-4">
        <div>
            <label class="block text-sm font-medium">Vezetéknév</label>
            <input name="last_name" value="{{ old('last_name') }}" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">Keresztnév</label>
            <input name="first_name" value="{{ old('first_name') }}" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">Irányítószám</label>
            <input name="zip_code" value="{{ old('zip_code') }}" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">Település</label>
            <input name="city" value="{{ old('city') }}" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">Utca, házszám</label>
            <input name="street_address" value="{{ old('street_address') }}" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">E-mail cím</label>
            <input type="email" name="email" value="{{ old('email') }}" required class="mt-1 w-full rounded border-gray-300" />
            <p class="text-xs text-gray-500 mt-1">Erre a címre küldjük a visszaigazolást.</p>
        </div>
        <div>
            <label class="block text-sm font-medium">Hány jegyet foglal</label>
            <input type="number" min="1" name="quantity" value="{{ old('quantity', 1) }}" required class="mt-1 w-full rounded border-gray-300" />
        </div>
        <div>
            <label class="block text-sm font-medium">Megjegyzés (opcionális)</label>
            <textarea name="note" rows="3" class="mt-1 w-full rounded border-gray-300">{{ old('note') }}</textarea>
        </div>

        <div class="flex items-center gap-4">
            <button type="submit" class="btn">Foglalás elküldése</button>
            <a href="{{ route('events.index') }}" class="underline">Vissza a listához</a>
        </div>
    </div>
</form>
