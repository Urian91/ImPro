@extends('layouts.app')
@section('content')
  <div class="card"><h1 class="text-xl font-bold mb-2">403</h1>
    <p>Nincs jogosultságod ehhez az oldalhoz.</p>
  </div>
@endsection
