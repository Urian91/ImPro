<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class EventController extends Controller
{
    public function index()
    {
        $events = Event::orderByDesc('starts_at')
            ->orderByDesc('created_at')
            ->paginate(15);

        return view('admin.events.index', compact('events'));
    }

    /** Új esemény űrlap */
    public function create()
    {
        return view('admin.events.create');
    }

    /** Új esemény mentése */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title'        => ['required','string','max:255'],
            'description'  => ['nullable','string'],
            'location'     => ['nullable','string','max:255'],
            'venue'        => ['nullable','string','max:255'],
            'city'         => ['nullable','string','max:255'],
            'starts_at'    => ['nullable','date'],
            'capacity'     => ['nullable','integer','min:0'],
            'is_published' => ['nullable','boolean'],
            'image'        => ['nullable','image','max:4096'],
        ]);

        $data = collect($validated)->only([
            'title','description','location','venue','city',
            'starts_at','capacity','is_published',
        ])->toArray();

        $data['is_published'] = $request->boolean('is_published');

        if ($request->hasFile('image')) {
            $data['image_path'] = $request->file('image')->store('events', 'public');
        }

        $event = Event::create($data);

        return redirect()
            ->route('admin.events.edit', $event)
            ->with('success', 'Új esemény létrehozva!');
    }

    public function edit(Event $event)
    {
        return view('admin.events.edit', compact('event'));
    }

    public function update(Request $request, Event $event)
    {
        $validated = $request->validate([
            'title'        => ['required','string','max:255'],
            'description'  => ['nullable','string'],
            'location'     => ['nullable','string','max:255'],
            'venue'        => ['nullable','string','max:255'],
            'city'         => ['nullable','string','max:255'],
            'starts_at'    => ['nullable','date'],
            'capacity'     => ['nullable','integer','min:0'],
            'is_published' => ['nullable','boolean'],
            'image'        => ['nullable','image','max:4096'],
        ]);

        $data = collect($validated)->only([
            'title','description','location','venue','city',
            'starts_at','capacity','is_published',
        ])->toArray();

        $data['is_published'] = $request->boolean('is_published');

        if ($request->hasFile('image')) {
            $path = $request->file('image')->store('events', 'public');
            $data['image_path'] = $path;

            if ($event->image_path && Storage::disk('public')->exists($event->image_path)) {
                Storage::disk('public')->delete($event->image_path);
            }
        }

        $event->update($data);

        return redirect()
            ->route('admin.events.edit', $event)
            ->with('success', 'Esemény frissítve.');
    }

    public function destroy(Event $event)
    {
        // Ha van kép, töröl
        if ($event->image_path && Storage::disk('public')->exists($event->image_path)) {
            Storage::disk('public')->delete($event->image_path);
        }

        $event->delete();

        return redirect()
            ->route('admin.events.index')
            ->with('success', 'Az esemény sikeresen törölve.');
    }
}
