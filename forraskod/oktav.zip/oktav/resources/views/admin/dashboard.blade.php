@extends('admin.layout')

@section('content')
<h1 class="text-2xl font-semibold mb-4">Admin kezdőlap</h1>
<p class="text-gray-600">Válassz a bal oldali menüből:</p>
<ul class="list-disc ml-6 mt-2">
    <li>Galéria kezelése – képek feltöltése, szerkesztése, törlése</li>
    <li>Fellépések kezelése – (hamarosan) események CRUD</li>
</ul>
@endsection
