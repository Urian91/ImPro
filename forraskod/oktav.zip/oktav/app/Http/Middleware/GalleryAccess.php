<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class GalleryAccess
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if (!$user) {
            return redirect()->route('login');
        }

        // csak admin VAGY gallery szerep
        if (!in_array($user->role, ['admin', 'gallery'], true)) {
            abort(403, 'Csak admin vagy galéria jogosultsággal érhető el.');
        }

        return $next($request);
    }
}
