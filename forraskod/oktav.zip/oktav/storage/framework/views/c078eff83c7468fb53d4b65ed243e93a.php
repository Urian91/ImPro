<?php $__env->startSection('content'); ?>
<h1 class="text-3xl font-bold mb-6">Fellépéseink</h1>

<?php if($events->isEmpty()): ?>
    <p class="text-gray-600">Jelenleg nincs meghirdetett esemény.</p>
<?php else: ?>
    <div class="space-y-6">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="border rounded-xl overflow-hidden">
                <div class="grid md:grid-cols-3 gap-0">
                    <div class="md:col-span-1">
                        <div style="aspect-ratio:16/9;background:#f3f4f6;overflow:hidden;">
                            <?php if($event->imageUrl()): ?>
                                <img src="<?php echo e($event->imageUrl()); ?>" alt="<?php echo e($event->title); ?>" style="width:100%;height:100%;object-fit:cover;">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="p-4 md:col-span-2">
                        <h2 class="text-xl font-semibold">
                            <a href="<?php echo e(route('events.show', $event)); ?>"><?php echo e($event->title); ?></a>
                        </h2>
                        <div class="text-gray-600 text-sm mb-2">
                            <?php echo e($event->starts_at->format('Y.m.d. H:i')); ?> • <?php echo e($event->venue); ?>, <?php echo e($event->city); ?>

                        </div>
                        <?php if($event->capacity): ?>
                            <div class="text-gray-600 text-sm mb-2">
                                Férőhely: <?php echo e($event->capacity); ?> • Hátralévő: <?php echo e($event->remainingCapacity()); ?>

                            </div>
                        <?php endif; ?>
                        <p class="mb-3 line-clamp-3"><?php echo e(Str::limit($event->description, 240)); ?></p>
                        <a href="<?php echo e(route('events.show', $event)); ?>" class="btn">Részletek & Foglalás</a>
                    </div>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oktav\resources\views/events/index.blade.php ENDPATH**/ ?>