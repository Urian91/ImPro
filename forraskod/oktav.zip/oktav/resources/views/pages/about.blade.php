@extends('layouts.app')
@section('title', 'Rólunk')

@section('content')
    <div class="space-y-6">
        {{-- HERO kép – fix magasság, nem csúszik szét --}}
        <div class="w-[120px] h-[120px]">
              <img src="{{ asset('images/rolunk.png') }}"
                 alt="ImPro – Rólunk"
             class="w-24 h-24 object-cover rounded-md border">
        </div>

        <div class="card space-y-3">
            <h1 class="text-2xl font-semibold">Rólunk</h1>
            <p class="text-gray-700">
                Üdvözlünk az ImPro világában, ahol az improvizáció nem csak művészet, hanem életforma! A hódmezővásárhelyi ImPro társulat, öt lelkes amatőr színész kooprudukciójából jött létre, akik bármikor készen állnak arra, hogy a színpadon a semmiből varázslatot teremtsenek. Hétpróbás humoristák, akik a spontaneitás művészetét űzik - néha még magukat is meglepik! Kacagtató jelenetek, váratlan fordulatok és színes karakterek várják a közönséget minden előadáson. Szóval, ha egy kis nevetésre és izgalmas színházi élményre vágysz, gyere el, és nézd meg, ahogy az ImPro csapata improvizál. Minden előadás egyedi és megismételhetetlen - akárcsak a nevetés, amit garantálunk!
            </p>
            {{-- ide jöhetnek további szekciók, fotók, stb. --}}
        </div>
    </div>
@endsection
