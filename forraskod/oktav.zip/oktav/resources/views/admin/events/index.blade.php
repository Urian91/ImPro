@extends('layouts.app')
@section('title', 'Fellépések kezelése')

@section('content')
    <div class="space-y-6">
        <div class="flex items-center justify-between">
            <h1 class="text-2xl font-semibold">Fellépések kezelése</h1>
            <div class="flex gap-3">
                <a href="{{ route('events.index') }}" class="underline">Publikus lista megnyitása</a>
                <a href="{{ route('admin.events.create') }}" class="btn">+ Új esemény</a>
            </div>
        </div>

        @if($events->isEmpty())
            <div class="card">Nincs még esemény.</div>
        @else
            <div class="space-y-3">
                @foreach($events as $event)
                    <div class="card space-y-2">
                        {{-- KÉP – ugyanaz a formátum, ami a publikus oldalon is jól működik --}}
                        <div>
                            @if(!empty($event->image_url))
                                <img src="{{ $event->image_url }}"
                                     alt="{{ $event->title }}"
                                     class="w-full h-40 object-cover rounded-md border">
                            @else
                                <img src="https://via.placeholder.com/400x200?text=ImPro"
                                     alt="ImPro"
                                     class="w-full h-40 object-cover rounded-md border">
                            @endif
                        </div>

                        {{-- SZÖVEG --}}
                        <div>
                            <div class="font-medium">
                                <a href="{{ route('events.show', $event) }}" target="_blank" class="underline">
                                    {{ $event->title }}
                                </a>
                                @if($event->is_published)
                                    <span class="ml-2 text-xs px-2 py-0.5 rounded bg-green-100 text-green-700">publikus</span>
                                @else
                                    <span class="ml-2 text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-600">rejtett</span>
                                @endif
                            </div>
                            <div class="text-sm text-gray-600">
                                @if($event->when)
                                    {{ $event->when->format('Y.m.d. H:i') }}
                                @endif
                                @if(!empty($event->city))
                                    • {{ $event->city }}
                                @endif
                                @if(!empty($event->venue))
                                    • {{ $event->venue }}
                                @endif
                            </div>
                        </div>

                        {{-- GOMB --}}
                        <div>
                            <a class="btn" href="{{ route('admin.events.edit', $event) }}">Szerkesztés</a>
                        </div>
                    </div>
                @endforeach
            </div>

            <div>
                {{ $events->links() }}
            </div>
        @endif
    </div>
@endsection
