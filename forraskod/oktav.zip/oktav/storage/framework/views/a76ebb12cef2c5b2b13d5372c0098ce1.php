<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto">
    <h1 class="text-3xl font-bold mb-6">Kapcsolat</h1>

    <div class="space-y-4 mb-8">
        <div>
            <h2 class="font-semibold">Telefon</h2>
            <p><a href="tel:<?php echo e($contact['phone']); ?>" class="text-blue-600 hover:underline"><?php echo e($contact['phone']); ?></a></p>
        </div>

        <div>
            <h2 class="font-semibold">E-mail</h2>
            <p><a href="mailto:<?php echo e($contact['email']); ?>" class="text-blue-600 hover:underline"><?php echo e($contact['email']); ?></a></p>
        </div>

        <div>
            <h2 class="font-semibold">Kapcsolattartó</h2>
            <p><?php echo e($contact['person']); ?></p>
        </div>

        <div>
            <h2 class="font-semibold">Cím</h2>
            <p><?php echo e($contact['address']); ?></p>
        </div>
    </div>

    <div class="rounded-lg overflow-hidden border">
        <iframe
            src="<?php echo e($contact['maps_embed']); ?>"
            width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade">
        </iframe>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oktav\resources\views/contact/index.blade.php ENDPATH**/ ?>