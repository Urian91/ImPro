@component('mail::message')
# Foglalás megerősítése

Kedves {{ $booking->fullName() }}!

Köszönjük a foglalást az alábbi eseményre:

**Esemény:** {{ $event->title }}
**Helyszín:** {{ $event->venue }}, {{ $event->city }}
**Időpont:** {{ $event->starts_at->format('Y.m.d. H:i') }}
**Jegyek száma:** {{ $booking->quantity }}

**Az Ön számlázási címe:** {{ $booking->fullAddress() }}

@component('mail::panel')
A foglalásod státusza: **{{ strtoupper($booking->status) }}**
@endcomponent

@component('mail::button', ['url' => route('events.show', $event)])
Esemény oldala
@endcomponent

Üdvözlettel,
**ImPro csapat**
@endcomponent
