<?php $__env->startSection('title', 'Fellépések kezelése'); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">
        <div class="flex items-center justify-between">
            <h1 class="text-2xl font-semibold">Fellépések kezelése</h1>
            <div class="flex gap-3">
                <a href="<?php echo e(route('events.index')); ?>" class="underline">Publikus lista megnyitása</a>
                <a href="<?php echo e(route('admin.events.create')); ?>" class="btn">+ Új esemény</a>
            </div>
        </div>

        <?php if($events->isEmpty()): ?>
            <div class="card">Nincs még esemény.</div>
        <?php else: ?>
            <div class="space-y-3">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card space-y-2">
                        
                        <div>
                            <?php if(!empty($event->image_url)): ?>
                                <img src="<?php echo e($event->image_url); ?>"
                                     alt="<?php echo e($event->title); ?>"
                                     class="w-full h-40 object-cover rounded-md border">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/400x200?text=ImPro"
                                     alt="ImPro"
                                     class="w-full h-40 object-cover rounded-md border">
                            <?php endif; ?>
                        </div>

                        
                        <div>
                            <div class="font-medium">
                                <a href="<?php echo e(route('events.show', $event)); ?>" target="_blank" class="underline">
                                    <?php echo e($event->title); ?>

                                </a>
                                <?php if($event->is_published): ?>
                                    <span class="ml-2 text-xs px-2 py-0.5 rounded bg-green-100 text-green-700">publikus</span>
                                <?php else: ?>
                                    <span class="ml-2 text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-600">rejtett</span>
                                <?php endif; ?>
                            </div>
                            <div class="text-sm text-gray-600">
                                <?php if($event->when): ?>
                                    <?php echo e($event->when->format('Y.m.d. H:i')); ?>

                                <?php endif; ?>
                                <?php if(!empty($event->city)): ?>
                                    • <?php echo e($event->city); ?>

                                <?php endif; ?>
                                <?php if(!empty($event->venue)): ?>
                                    • <?php echo e($event->venue); ?>

                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div>
                            <a class="btn" href="<?php echo e(route('admin.events.edit', $event)); ?>">Szerkesztés</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div>
                <?php echo e($events->links()); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oktav\resources\views/admin/events/index.blade.php ENDPATH**/ ?>