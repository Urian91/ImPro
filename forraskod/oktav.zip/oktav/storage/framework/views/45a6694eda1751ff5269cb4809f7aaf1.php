<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'ImPro'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <link rel="icon" type="image/png" href="<?php echo e(asset('images/logo.png')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(asset('images/logo.png')); ?>">

    <style>
        :root{ --container-w:1100px; }
        body {
            background: #fff url("<?php echo e(asset('images/bg.jpg')); ?>") no-repeat center top / cover fixed;
            color:#111;
        }
        .backdrop { background: rgba(255,255,255,.85); -webkit-backdrop-filter: blur(2px); backdrop-filter: blur(2px); }
        .container { max-width: var(--container-w); margin: 0 auto; padding: 1rem; }
        .nav a { padding: .5rem .75rem; border-radius: .5rem; }
        .nav a:hover { background: rgba(0,0,0,.06); }
        .nav a.active { font-weight: 600; background: rgba(0,0,0,.08); }
        .btn { display:inline-block; padding:.6rem 1rem; border-radius:.6rem; background:#111;color:#fff; text-decoration:none}
        .btn:hover { opacity:.9 }
        .card { border:1px solid #e5e7eb; border-radius:.75rem; padding:1rem }
        header, footer { background: rgba(255,255,255,.9); }
        .brand-img { height: 36px; width: auto; display:block }
        @media (max-width: 768px) { .nav { gap:.25rem; flex-wrap: wrap } }
    </style>
</head>
<body class="antialiased">
<header class="border-b">
    <div class="container flex items-center justify-between">
        
        <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2" aria-label="ImPro – Kezdőlap">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="ImPro" class="brand-img">
        </a>

        <nav class="nav flex items-center gap-2">
            
            <a href="<?php echo e(route('about')); ?>" class="<?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">Rólunk</a>
            <a href="<?php echo e(route('events.index')); ?>" class="<?php echo e(request()->routeIs('events.*') ? 'active' : ''); ?>">Fellépéseink</a>
            <a href="<?php echo e(route('gallery.index')); ?>" class="<?php echo e(request()->routeIs('gallery.index') ? 'active' : ''); ?>">Galéria</a>
            <a href="<?php echo e(route('contact.index')); ?>" class="<?php echo e(request()->routeIs('contact.index') ? 'active' : ''); ?>">Kapcsolat</a>

            <?php if(auth()->guard()->check()): ?>
                
                <a href="<?php echo e(route('admin.home')); ?>" class="<?php echo e(request()->is('admin*') ? 'active' : ''); ?>">
                    Admin
                </a>

                

                
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="ml-2" style="padding:.5rem .75rem;border-radius:.5rem">Kijelentkezés</button>
                </form>
            <?php endif; ?>

            
        </nav>
    </div>
</header>

<main class="container py-8 backdrop">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer class="border-t">
    <div class="container py-6 text-sm text-gray-700">
        &copy; <?php echo e(date('Y')); ?> ImPro • Minden jog fenntartva
    </div>
</footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\oktav\resources\views/layouts/app.blade.php ENDPATH**/ ?>