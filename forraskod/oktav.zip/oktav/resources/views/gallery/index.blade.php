@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto">
    <h1 class="text-3xl font-bold mb-6">Galéria</h1>

    @if($images->isEmpty())
        <p class="text-gray-600">Még nincs feltöltött kép.</p>
    @else
        {{-- Egyszerű, reszponzív "masonry" mozaik columns-szal --}}
        <style>
            .masonry {
                columns: 1;
                column-gap: 1rem;
            }
            @media (min-width: 640px) { .masonry { columns: 2; } }
            @media (min-width: 1024px){ .masonry { columns: 3; } }
            .masonry-item {
                break-inside: avoid;
                margin-bottom: 1rem;
                border-radius: .75rem;
                overflow: hidden;
                border: 1px solid #e5e7eb;
                background: #fff;
                display: block;
            }
            .masonry-item img { width: 100%; height: auto; display: block; }
            .masonry-caption {
                font-size: .875rem; color: #6b7280; padding: .5rem .75rem;
            }
        </style>

        <div class="masonry">
            @foreach($images as $img)
                <figure class="masonry-item">
                    <img src="{{ asset('storage/'.$img->path) }}" alt="{{ $img->alt_text ?? 'Galeria kép' }}">
                    @if($img->alt_text)
                        <figcaption class="masonry-caption">{{ $img->alt_text }}</figcaption>
                    @endif
                </figure>
            @endforeach
        </div>
    @endif
</div>
@endsection
