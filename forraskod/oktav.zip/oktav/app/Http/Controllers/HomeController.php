<?php

namespace App\Http\Controllers;

use App\Models\Event;

class HomeController extends Controller
{

    public function index()
    {
        $upcoming = Event::query()
            ->where('is_published', true)
            ->where('starts_at', '>=', now()->subDay())
            ->orderBy('starts_at')
            ->limit(3)
            ->get();

        return view('home.index', [
            'upcoming' => $upcoming,
        ]);
    }
}
