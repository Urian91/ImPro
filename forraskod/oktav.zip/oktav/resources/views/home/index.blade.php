@extends('layouts.app')

@section('content')
    {{-- HERO --}}
    <section class="mb-10">
        <h1 class="text-3xl font-bold mb-3">Üdv az ImPro oldalán!</h1>
        <p class="text-gray-600 mb-6">
            Nézz körül, ismerd meg a csapatot, és foglalj jegyet a közelgő fellépéseinkre.
        </p>
        <a href="{{ route('events.index') }}" class="btn">Fellépések megtekintése</a>
    </section>

    {{-- KÖZELGŐ 3 FELLÉPÉS --}}
    <section>
        <h2 class="text-2xl font-semibold mb-4">Közelgő fellépések</h2>

        @if($upcoming->isEmpty())
            <div class="text-gray-600">Jelenleg nincs meghirdetett esemény.</div>
        @else
            <div class="grid md:grid-cols-3 gap-4">
                @foreach($upcoming as $event)
                    <article class="card space-y-3">
                        {{-- Kép --}}
                        <div>
                            @if(!empty($event->image_url))
                                <img src="{{ $event->image_url }}"
                                     alt="{{ $event->title }}"
                                     class="w-full h-40 object-cover rounded-md border">
                            @else
                                <img src="https://via.placeholder.com/400x200?text=ImPro"
                                     alt="ImPro"
                                     class="w-full h-40 object-cover rounded-md border">
                            @endif
                        </div>

                        {{-- Cím --}}
                        <h3 class="font-semibold text-lg">
                            <a href="{{ route('events.show', $event) }}">{{ $event->title }}</a>
                        </h3>

                        {{-- Helyszín + időpont --}}
                        <div class="text-sm text-gray-600">
                            {{ $event->venue }}, {{ $event->city }}<br>
                            {{ $event->formattedWhen('Y.m.d. H:i') }}
                        </div>

                        {{-- Jegyfoglalás --}}
                        <div>
                            <a class="btn w-full text-center" style="background:#2563eb" href="{{ route('events.show', $event) }}">
                                Jegyet foglalok
                            </a>
                        </div>
                    </article>
                @endforeach
            </div>
        @endif
    </section>
@endsection
