<?php

namespace App\Mail;

use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class BookingConfirmedMail extends Mailable
{
    use Queueable, SerializesModels;

    public Booking $booking;

    /**
     * @param Booking $booking
     */
    public function __construct(Booking $booking)
    {
        $this->booking = $booking;
    }

    public function build()
    {
        $event = $this->booking->event;

        return $this->subject('Foglalás megerősítése – ' . $event->title)
            ->markdown('emails.booking.confirmed', [
                'booking' => $this->booking,
                'event'   => $event,
            ]);
    }
}
