<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // event_id (FK az events.id-re)
        if (!Schema::hasColumn('bookings', 'event_id')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->unsignedBigInteger('event_id')->nullable();
            });
            // külön lépésben FK (ha már létezik az events tábla)
            if (Schema::hasTable('events')) {
                Schema::table('bookings', function (Blueprint $table) {
                    // ha véletlen már van kulcs, ne dőljön el
                    try {
                        $table->foreign('event_id')->references('id')->on('events')->cascadeOnDelete();
                    } catch (\Throwable $e) { /* ignore */ }
                });
            }
        }

        // alap adatok
        if (!Schema::hasColumn('bookings', 'full_name')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->string('full_name', 120)->nullable();
            });
        }
        if (!Schema::hasColumn('bookings', 'address')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->string('address', 255)->nullable();
            });
        }
        if (!Schema::hasColumn('bookings', 'email')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->string('email', 190)->nullable();
            });
        }

        // mennyiség
        if (!Schema::hasColumn('bookings', 'quantity')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->unsignedInteger('quantity')->default(1);
            });
        }

        // opcionális mezők
        if (!Schema::hasColumn('bookings', 'note')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->text('note')->nullable();
            });
        }
        if (!Schema::hasColumn('bookings', 'status')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->string('status', 30)->default('confirmed');
            });
        }
    }

    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            // biztonságosan engedjük el az FK-t, ha van
            if (Schema::hasColumn('bookings', 'event_id')) {
                try {
                    $table->dropForeign(['event_id']);
                } catch (\Throwable $e) { /* ignore */ }
            }
        });

        // oszlopok visszavétele (ha léteznek)
        foreach (['status','note','quantity','email','address','full_name','event_id'] as $col) {
            if (Schema::hasColumn('bookings', $col)) {
                Schema::table('bookings', function (Blueprint $table) use ($col) {
                    $table->dropColumn($col);
                });
            }
        }
    }
};
