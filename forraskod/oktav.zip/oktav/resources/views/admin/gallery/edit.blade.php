@extends('admin.layout')

@section('content')
<h1 class="text-2xl font-semibold mb-4">Kép szerkesztése</h1>

<div class="grid md:grid-cols-2 gap-6">
    <div>
        <img src="{{ asset('storage/'.$img->path) }}" alt="{{ $img->alt_text ?? '' }}" class="border rounded">
    </div>
    <div>
        <form action="{{ route('admin.gallery.update', $img) }}" method="POST" enctype="multipart/form-data" class="space-y-3">
            @csrf @method('PUT')

            <label class="block">ALT szöveg
                <input type="text" name="alt_text" value="{{ old('alt_text', $img->alt_text) }}" class="border rounded p-2 w-full">
            </label>

            <label class="block">Sorrend
                <input type="number" name="sort_order" value="{{ old('sort_order', $img->sort_order) }}" min="0" class="border rounded p-2 w-full">
            </label>

            <label class="block">Kép cseréje (opcionális)
                <input type="file" name="replace" accept="image/*" class="border rounded p-2 w-full">
            </label>

            <div class="pt-2">
                <button class="px-4 py-2 bg-black text-white rounded">Mentés</button>
                <a href="{{ route('admin.gallery.index') }}" class="ml-2 underline">Vissza</a>
            </div>
        </form>
    </div>
</div>
@endsection
