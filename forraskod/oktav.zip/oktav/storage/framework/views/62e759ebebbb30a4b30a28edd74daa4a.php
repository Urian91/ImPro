<?php $__env->startSection('title', $event->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">

        
        <div class="card space-y-4">
            
            <div>
                <?php if(!empty($event->image_url)): ?>
                    <img src="<?php echo e($event->image_url); ?>"
                         alt="<?php echo e($event->title); ?>"
                         class="w-full h-40 object-cover rounded-md border">
                <?php else: ?>
                    <img src="https://via.placeholder.com/400x200?text=ImPro"
                         alt="ImPro"
                         class="w-full h-40 object-cover rounded-md border">
                <?php endif; ?>
            </div>

            
            <div class="space-y-3">
                <h2 class="text-xl font-semibold"><?php echo e($event->title); ?></h2>

                <?php if(!empty($event->description)): ?>
                    <p class="text-gray-700"><?php echo e($event->description); ?></p>
                <?php endif; ?>

                <div class="text-sm text-gray-600 space-y-1">
                    <?php if(!empty($event->location)): ?>
                        <p><strong>Helyszín:</strong> <?php echo e($event->location); ?></p>
                    <?php endif; ?>

                    <?php if($event->when): ?>
                        <p><strong>Időpont:</strong> <?php echo e($event->when->format('Y.m.d. H:i')); ?></p>
                    <?php endif; ?>

                    <?php $left = method_exists($event, 'remainingCapacity') ? $event->remainingCapacity() : null; ?>
                    <?php if(!is_null($left)): ?>
                        <p class="<?php echo e($left === 0 ? 'text-red-600' : 'text-gray-600'); ?>">
                            <strong>Hátralévő férőhely:</strong> <?php echo e($left); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <h3 id="foglalas" class="text-lg font-semibold">Foglalás</h3>

        
        <?php echo $__env->make('bookings._form', ['event' => $event], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oktav\resources\views/events/show.blade.php ENDPATH**/ ?>