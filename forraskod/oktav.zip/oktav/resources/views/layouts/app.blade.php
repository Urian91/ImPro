<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? 'ImPro' }}</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <link rel="icon" type="image/png" href="{{ asset('images/logo.png') }}">
    <link rel="apple-touch-icon" href="{{ asset('images/logo.png') }}">

    <style>
        :root{ --container-w:1100px; }
        body {
            background: #fff url("{{ asset('images/bg.jpg') }}") no-repeat center top / cover fixed;
            color:#111;
        }
        .backdrop { background: rgba(255,255,255,.85); -webkit-backdrop-filter: blur(2px); backdrop-filter: blur(2px); }
        .container { max-width: var(--container-w); margin: 0 auto; padding: 1rem; }
        .nav a { padding: .5rem .75rem; border-radius: .5rem; }
        .nav a:hover { background: rgba(0,0,0,.06); }
        .nav a.active { font-weight: 600; background: rgba(0,0,0,.08); }
        .btn { display:inline-block; padding:.6rem 1rem; border-radius:.6rem; background:#111;color:#fff; text-decoration:none}
        .btn:hover { opacity:.9 }
        .card { border:1px solid #e5e7eb; border-radius:.75rem; padding:1rem }
        header, footer { background: rgba(255,255,255,.9); }
        .brand-img { height: 36px; width: auto; display:block }
        @media (max-width: 768px) { .nav { gap:.25rem; flex-wrap: wrap } }
    </style>
</head>
<body class="antialiased">
<header class="border-b">
    <div class="container flex items-center justify-between">
        {{-- Logo / brand --}}
        <a href="{{ route('home') }}" class="flex items-center gap-2" aria-label="ImPro – Kezdőlap">
            <img src="{{ asset('images/logo.png') }}" alt="ImPro" class="brand-img">
        </a>

        <nav class="nav flex items-center gap-2">
            {{-- Publikus menü --}}
            <a href="{{ route('about') }}" class="{{ request()->routeIs('about') ? 'active' : '' }}">Rólunk</a>
            <a href="{{ route('events.index') }}" class="{{ request()->routeIs('events.*') ? 'active' : '' }}">Fellépéseink</a>
            <a href="{{ route('gallery.index') }}" class="{{ request()->routeIs('gallery.index') ? 'active' : '' }}">Galéria</a>
            <a href="{{ route('contact.index') }}" class="{{ request()->routeIs('contact.index') ? 'active' : '' }}">Kapcsolat</a>

            @auth
                {{-- Egységes Admin belépő: szerep szerint visz (admin.home) --}}
                <a href="{{ route('admin.home') }}" class="{{ request()->is('admin*') ? 'active' : '' }}">
                    Admin
                </a>

                {{-- Opcionális: külön linkek, ha szeretnéd megtartani
                @can('admin')
                    <a href="{{ route('admin.events.index') }}" class="{{ request()->routeIs('admin.events.*') ? 'active' : '' }}">Fellépések (admin)</a>
                @endcan
                @can('manage-gallery')
                    <a href="{{ route('admin.gallery.index') }}" class="{{ request()->routeIs('admin.gallery.*') ? 'active' : '' }}">Galéria (admin)</a>
                @endcan
                --}}

                {{-- Kijelentkezés --}}
                <form method="POST" action="{{ route('logout') }}" class="inline">
                    @csrf
                    <button type="submit" class="ml-2" style="padding:.5rem .75rem;border-radius:.5rem">Kijelentkezés</button>
                </form>
            @endauth

            {{-- Vendég linkek szándékosan rejtve
            @guest
                <a href="{{ route('login') }}">Bejelentkezés</a>
                <a href="{{ route('register') }}" class="btn">Regisztráció</a>
            @endguest
            --}}
        </nav>
    </div>
</header>

<main class="container py-8 backdrop">
    @yield('content')
</main>

<footer class="border-t">
    <div class="container py-6 text-sm text-gray-700">
        &copy; {{ date('Y') }} ImPro • Minden jog fenntartva
    </div>
</footer>
</body>
</html>
