<?php

namespace App\Http\Controllers;

use App\Models\GalleryImage;

class GalleryController extends Controller
{
    public function index()
    {
        $images = GalleryImage::query()
            ->orderBy('sort_order')
            ->orderByDesc('created_at')
            ->get();

        $title = 'Galéria – ImPro';
        return view('gallery.index', compact('title', 'images'));
    }
}
