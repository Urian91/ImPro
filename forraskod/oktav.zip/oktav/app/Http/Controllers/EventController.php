<?php

namespace App\Http\Controllers;

use App\Models\Event;

class EventController extends Controller
{
    public function index()
    {
        $events = Event::where('is_published', true)
            ->orderBy('starts_at')
            ->get();

        return view('events.index', compact('events'));
    }

    public function show(Event $event)
    {
        // Ha lejárt esemény, külön landinget mutatunk
        if ($event->isPast()) {
            return view('events.past', compact('event'));
        }

        // Élő esemény oldal (normál űrlappal)
        return view('events.show', compact('event'));
    }
}
