@extends('layouts.app')
@section('title', 'Foglalás – ' . $event->title)

@section('content')
    <div class="space-y-6">
        <div class="card">
            <h2 class="text-lg font-semibold">Foglalás – {{ $event->title }}</h2>
            @isset($spotsLeft)
                <p class="text-sm text-gray-600 mt-1">Hátralévő férőhely: {{ $spotsLeft }}</p>
            @endisset
        </div>

        @include('bookings._form', ['event' => $event])
    </div>
@endsection
