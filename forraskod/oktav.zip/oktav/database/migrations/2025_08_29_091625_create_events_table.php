<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('events', function (Blueprint $table) {
            if (!Schema::hasColumn('events', 'title')) {
                $table->string('title', 190)->after('id');
            }
            if (!Schema::hasColumn('events', 'starts_at')) {
                $table->dateTime('starts_at')->after('title');
            }
            if (!Schema::hasColumn('events', 'location')) {
                $table->string('location', 190)->nullable()->after('starts_at');
            }
            if (!Schema::hasColumn('events', 'capacity')) {
                $table->unsignedInteger('capacity')->nullable()->after('location'); // null = korlátlan
            }
            if (!Schema::hasColumn('events', 'description')) {
                $table->text('description')->nullable()->after('capacity');
            }
            if (!Schema::hasColumn('events', 'image_path')) {
                $table->string('image_path', 255)->nullable()->after('description');
            }
            if (!Schema::hasColumn('events', 'is_published')) {
                $table->boolean('is_published')->default(true)->after('image_path');
            }
        });
    }

    public function down(): void
    {
        Schema::table('events', function (Blueprint $table) {
            $cols = ['title','starts_at','location','capacity','description','image_path','is_published'];
            foreach ($cols as $col) {
                if (Schema::hasColumn('events', $col)) {
                    $table->dropColumn($col);
                }
            }
        });
    }
};
