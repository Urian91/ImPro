<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'event_id',
        'last_name', 'first_name',
        'zip_code', 'city', 'street_address',
        'email',
        'quantity', 'note', 'status',
    ];

    public function event()
    {
        return $this->belongsTo(Event::class);
    }


    public function fullName(): string
    {
        return trim(($this->last_name ?? '') . ' ' . ($this->first_name ?? ''));
    }


    public function fullAddress(): string
    {
        $parts = array_filter([
            $this->zip_code,
            $this->city,
            $this->street_address,
        ]);
        return implode(', ', $parts);
    }
}
