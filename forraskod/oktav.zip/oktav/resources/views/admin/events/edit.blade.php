@extends('layouts.app')
@section('title', 'Esemény szerkesztése: ' . $event->title)

@section('content')
<div class="space-y-6">

    <a href="{{ route('admin.events.index') }}" class="underline">← Vissza a listához</a>

    @if(session('success'))
        <div class="card bg-green-50 border-green-200 text-green-800">{{ session('success') }}</div>
    @endif

    <form action="{{ route('admin.events.update', $event) }}" method="POST" enctype="multipart/form-data" class="card space-y-4">
        @csrf
        @method('PUT')

        <div>
            <label class="block text-sm font-medium">Cím</label>
            <input name="title" value="{{ old('title', $event->title) }}" class="mt-1 w-full rounded border-gray-300" required>
            @error('title') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
        </div>

        <div>
            <label class="block text-sm font-medium">Leírás</label>
            <textarea name="description" rows="6" class="mt-1 w-full rounded border-gray-300">{{ old('description', $event->description) }}</textarea>
            @error('description') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium">Helyszín</label>
                <input name="location" value="{{ old('location', $event->location) }}" class="mt-1 w-full rounded border-gray-300">
                @error('location') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="block text-sm font-medium">Város</label>
                <input name="city" value="{{ old('city', $event->city) }}" class="mt-1 w-full rounded border-gray-300">
                @error('city') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
            </div>
        </div>

        <div>
            <label for="starts_at" class="block text-sm font-medium">Időpont</label>
            <input
                type="datetime-local"
                id="starts_at"
                name="starts_at"
                value="{{ old('starts_at', $event->starts_at ? $event->starts_at->format('Y-m-d\TH:i') : '') }}"
                class="mt-1 w-full rounded border-gray-300"
            >
            @error('starts_at') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium">Férőhely</label>
                <input type="number" name="capacity" value="{{ old('capacity', $event->capacity) }}" class="mt-1 w-full rounded border-gray-300">
                @error('capacity') <p class="text-sm text-red-600">{{ $message }}</p> @enderror
            </div>
            <label class="inline-flex items-center gap-2 mt-6">
                <input type="checkbox" name="is_published" value="1" {{ old('is_published', $event->is_published) ? 'checked' : '' }}>
                <span>Publikus</span>
            </label>
        </div>

        <div>
            <label class="block text-sm font-medium">Kép feltöltése</label>
            <input type="file" name="image" class="mt-1">
            @error('image') <p class="text-sm text-red-600">{{ $message }}</p> @enderror

            @if($event->image_url)
                <div class="mt-3">
                    <img src="{{ $event->image_url }}" alt="borító"
                         class="w-full h-40 object-cover rounded-md border">
                </div>
            @endif
        </div>

        <div class="flex gap-3">
            <button class="btn">Mentés</button>
            <a href="{{ route('events.show', $event) }}" class="underline" target="_blank">Megnézem az oldalon</a>
        </div>
    </form>

    {{-- Törlés gomb --}}
    <form action="{{ route('admin.events.destroy', $event) }}" method="POST" class="mt-6"
          onsubmit="return confirm('Biztosan törlöd az eseményt? Ez a művelet nem visszavonható!')">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn bg-red-600 hover:bg-red-700">
            Esemény törlése
        </button>
    </form>
</div>
@endsection
