@extends('layouts.app')
@section('title', 'Sikertelen foglalás')

@section('content')
    <div class="max-w-2xl mx-auto space-y-6">
        <div class="card">
            <h1 class="text-2xl font-semibold mb-2">Sikertelen foglalás</h1>

            <p class="text-gray-700">
                Sajnos kevés a szabad hely ehhez a darabszámhoz.
                @isset($spotsLeft)
                    Jelenleg elérhető: <strong>{{ $spotsLeft }}</strong> férőhely.
                @endisset
            </p>

            <div class="mt-6 flex gap-3">
                <a href="{{ route('events.show', $event) }}" class="btn">Vissza az eseményhez</a>
                <a href="{{ route('events.index') }}" class="btn" style="background:#2563eb">
                    Fellépések megtekintése
                </a>
            </div>
        </div>
    </div>
@endsection
