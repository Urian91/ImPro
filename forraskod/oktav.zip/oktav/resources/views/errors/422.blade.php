@extends('layouts.app')
@section('title', 'Sikertelen foglalás')

@section('content')
    <div class="max-w-2xl mx-auto space-y-6">
        <div class="card">
            <h1 class="text-2xl font-semibold mb-2">Sikertelen foglalás</h1>

            <p class="text-gray-700">
                {{-- Ha a controller adott egyedi üzenetet, azt mutatjuk; különben alapértelmezett szöveg --}}
                {{ $exception?->getMessage() ?: 'Valamiért nem sikerült feldolgozni a kérést.' }}
            </p>

            <div class="mt-4 text-sm text-gray-600">
                Ha kevesebb jegyet szeretnél, térj vissza az esemény oldalára és próbáld újra.
            </div>

            <div class="mt-6 flex flex-wrap gap-3">
                {{-- Vissza az előző oldalra --}}
                <a href="{{ url()->previous() }}" class="btn">Vissza</a>

                {{-- Fellépések listája --}}
                <a href="{{ route('events.index') }}" class="btn" style="background:#2563eb">
                    Fellépések megtekintése
                </a>
            </div>
        </div>

        {{-- Opcionális tippdoboz --}}
        <div class="card bg-yellow-50 border-yellow-200 text-yellow-900">
            Tipp: Ha sokan foglalnak egyszerre, előfordulhat, hogy a szabad helyek gyorsan elfogynak.
            Próbáld meg kisebb darabszámmal!
        </div>
    </div>
@endsection
