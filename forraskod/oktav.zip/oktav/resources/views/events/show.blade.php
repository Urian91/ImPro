@extends('layouts.app')
@section('title', $event->title)

@section('content')
    <div class="space-y-6">

        {{-- ESEMÉNY KÁRTYA – felül a kép fix magassággal, alatta a tartalom --}}
        <div class="card space-y-4">
            {{-- Kép --}}
            <div>
                @if(!empty($event->image_url))
                    <img src="{{ $event->image_url }}"
                         alt="{{ $event->title }}"
                         class="w-full h-40 object-cover rounded-md border">
                @else
                    <img src="https://via.placeholder.com/400x200?text=ImPro"
                         alt="ImPro"
                         class="w-full h-40 object-cover rounded-md border">
                @endif
            </div>

            {{-- Cím + leírás + adatok --}}
            <div class="space-y-3">
                <h2 class="text-xl font-semibold">{{ $event->title }}</h2>

                @if(!empty($event->description))
                    <p class="text-gray-700">{{ $event->description }}</p>
                @endif

                <div class="text-sm text-gray-600 space-y-1">
                    @if(!empty($event->location))
                        <p><strong>Helyszín:</strong> {{ $event->location }}</p>
                    @endif

                    @if($event->when)
                        <p><strong>Időpont:</strong> {{ $event->when->format('Y.m.d. H:i') }}</p>
                    @endif

                    @php $left = method_exists($event, 'remainingCapacity') ? $event->remainingCapacity() : null; @endphp
                    @if(!is_null($left))
                        <p class="{{ $left === 0 ? 'text-red-600' : 'text-gray-600' }}">
                            <strong>Hátralévő férőhely:</strong> {{ $left }}
                        </p>
                    @endif
                </div>
            </div>
        </div>

        {{-- Foglalási űrlap cím --}}
        <h3 id="foglalas" class="text-lg font-semibold">Foglalás</h3>

        {{-- Foglalási űrlap (a partial csak a mezőket tartalmazza) --}}
        @include('bookings._form', ['event' => $event])

    </div>
@endsection
