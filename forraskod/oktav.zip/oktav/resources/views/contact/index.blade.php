@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto">
    <h1 class="text-3xl font-bold mb-6">Kapcsolat</h1>

    <div class="space-y-4 mb-8">
        <div>
            <h2 class="font-semibold">Telefon</h2>
            <p><a href="tel:{{ $contact['phone'] }}" class="text-blue-600 hover:underline">{{ $contact['phone'] }}</a></p>
        </div>

        <div>
            <h2 class="font-semibold">E-mail</h2>
            <p><a href="mailto:{{ $contact['email'] }}" class="text-blue-600 hover:underline">{{ $contact['email'] }}</a></p>
        </div>

        <div>
            <h2 class="font-semibold">Kapcsolattartó</h2>
            <p>{{ $contact['person'] }}</p>
        </div>

        <div>
            <h2 class="font-semibold">Cím</h2>
            <p>{{ $contact['address'] }}</p>
        </div>
    </div>

    <div class="rounded-lg overflow-hidden border">
        <iframe
            src="{{ $contact['maps_embed'] }}"
            width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade">
        </iframe>
    </div>
</div>
@endsection
