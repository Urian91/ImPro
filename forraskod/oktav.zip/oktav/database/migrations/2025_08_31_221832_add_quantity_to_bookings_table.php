<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Ha nincs email oszlop, előbb azt pótoljuk (nullable, hogy biztos lefusson)
        if (!Schema::hasColumn('bookings', 'email')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->string('email', 190)->nullable();
            });
        }

        // Majd felvesszük a quantity-t (pozicionálás NÉLKÜL)
        if (!Schema::hasColumn('bookings', 'quantity')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->unsignedInteger('quantity')->default(1);
            });
        }
    }

    public function down(): void
    {
        // Quantity visszavétele, ha létezik
        if (Schema::hasColumn('bookings', 'quantity')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->dropColumn('quantity');
            });
        }


    }
};
