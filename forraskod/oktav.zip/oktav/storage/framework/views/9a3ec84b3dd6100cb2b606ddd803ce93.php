<?php $__env->startSection('content'); ?>
  <div class="card"><h1 class="text-xl font-bold mb-2">403</h1>
    <p>Nincs jogosultságod ehhez az oldalhoz.</p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oktav\resources\views/errors/403.blade.php ENDPATH**/ ?>